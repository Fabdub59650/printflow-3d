/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: printflow
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `action` varchar(30) NOT NULL,
  `detail` varchar(500) DEFAULT NULL,
  `diff` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_entity` (`entity`,`entity_id`),
  KEY `idx_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `consumable_templates`
--

DROP TABLE IF EXISTS `consumable_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumable_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `default_hours` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumable_templates`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `consumable_templates` WRITE;
/*!40000 ALTER TABLE `consumable_templates` DISABLE KEYS */;
INSERT INTO `consumable_templates` VALUES
(1,'Huile rails X/Y',200,'Lubrification des rails de guidage'),
(2,'Lubrifiant vis mère Z',300,'Graissage de la vis trapézoïdale Z'),
(3,'Filtre HEPA',500,'Remplacement du filtre à particules'),
(4,'Filtre charbon actif',400,'Remplacement du filtre aux odeurs'),
(5,'Nettoyage buse',100,'Nettoyage ou remplacement de la buse'),
(6,'Nettoyage plateau',50,'Nettoyage en profondeur du plateau'),
(7,'Vérification courroies',500,'Tension et usure des courroies'),
(8,'Calibration XYZ',200,'Recalibration complète des axes');
/*!40000 ALTER TABLE `consumable_templates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `consumables`
--

DROP TABLE IF EXISTS `consumables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `printer_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'ex: Huile rails X/Y',
  `interval_hours` int(11) NOT NULL DEFAULT 200 COMMENT 'Intervalle de remplacement en heures',
  `reset_at` timestamp NULL DEFAULT NULL COMMENT 'Date de la dernière réinitialisation',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `printer_id` (`printer_id`),
  CONSTRAINT `consumables_ibfk_1` FOREIGN KEY (`printer_id`) REFERENCES `printers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumables`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `consumables` WRITE;
/*!40000 ALTER TABLE `consumables` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumables` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `filament_weighings`
--

DROP TABLE IF EXISTS `filament_weighings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filament_weighings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filament_id` int(11) NOT NULL,
  `gross_weight` decimal(8,2) NOT NULL COMMENT 'Poids brut lu sur balance (g)',
  `spool_weight` decimal(8,2) DEFAULT NULL COMMENT 'Poids bobine vide utilisé (g)',
  `net_weight` decimal(8,2) NOT NULL COMMENT 'Poids filament calculé (g)',
  `previous_weight` decimal(8,2) NOT NULL COMMENT 'Ancien poids restant avant pesée',
  `notes` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `filament_id` (`filament_id`),
  CONSTRAINT `filament_weighings_ibfk_1` FOREIGN KEY (`filament_id`) REFERENCES `filaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filament_weighings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `filament_weighings` WRITE;
/*!40000 ALTER TABLE `filament_weighings` DISABLE KEYS */;
/*!40000 ALTER TABLE `filament_weighings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `filaments`
--

DROP TABLE IF EXISTS `filaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filaments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `material` enum('PLA','PETG','ABS','ASA','TPU','Nylon','PC','HIPS','PVA','autre') DEFAULT 'PLA',
  `color_name` varchar(50) DEFAULT NULL,
  `color_hex` varchar(7) DEFAULT '#cccccc',
  `diameter` decimal(4,2) DEFAULT 1.75,
  `temp_nozzle_min` int(11) DEFAULT 190,
  `temp_nozzle_max` int(11) DEFAULT 230,
  `temp_bed_min` int(11) DEFAULT 0,
  `temp_bed_max` int(11) DEFAULT 60,
  `weight_total` decimal(8,2) DEFAULT 1000.00,
  `weight_remaining` decimal(8,2) DEFAULT 1000.00,
  `price` decimal(8,2) DEFAULT NULL,
  `spoolman_id` int(11) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `archived` tinyint(1) DEFAULT 0,
  `nfc_uid` varchar(32) DEFAULT NULL COMMENT 'UID puce NFC liée à cette bobine',
  `spool_number` varchar(50) DEFAULT NULL COMMENT 'Numéro ou référence de la bobine',
  `elegoo_subtype` varchar(20) DEFAULT NULL COMMENT 'Sous-type ELEGOO pour encodage NFC',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `finish_option` varchar(50) DEFAULT NULL COMMENT 'Finition : brillant, mat, soie, marbre, bois, carbone…',
  `special_option` varchar(50) DEFAULT NULL COMMENT 'Propriété : renforcé, flexible, conducteur…',
  `spool_weight` decimal(7,2) DEFAULT NULL COMMENT 'Poids de la bobine vide en grammes',
  `stock_alert_threshold` int(11) DEFAULT 20 COMMENT 'Pourcentage restant déclenchant l alerte (0=désactivé)',
  `parent_filament_id` int(11) DEFAULT NULL COMMENT 'ID du filament parent si bobine partielle',
  `spool_label` varchar(50) DEFAULT NULL COMMENT 'Étiquette libre ex: Bobine A, Reste commande mars',
  PRIMARY KEY (`id`),
  KEY `fk_filament_parent` (`parent_filament_id`),
  CONSTRAINT `fk_filament_parent` FOREIGN KEY (`parent_filament_id`) REFERENCES `filaments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filaments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `filaments` WRITE;
/*!40000 ALTER TABLE `filaments` DISABLE KEYS */;
INSERT INTO `filaments` VALUES
(1,'PLA Blanc','eSUN','PLA','Blanc','#f5f5f0',1.75,190,230,0,60,1000.00,720.00,22.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL),
(2,'PLA Rouge','Polymaker','PLA','Rouge','#e24b4a',1.75,190,230,0,60,1000.00,580.00,24.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL),
(3,'PLA Gris clair','eSUN','PLA','Gris clair','#cccccc',1.75,190,230,0,60,1000.00,87.00,22.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL),
(4,'PETG Noir','Bambu Lab','PETG','Noir','#2c2c2a',1.75,190,230,0,60,1000.00,440.00,28.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL),
(5,'PETG Bleu marine','Polymaker','PETG','Bleu marine','#2563eb',1.75,190,230,0,60,1000.00,120.00,26.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL),
(6,'TPU Vert','Filaflex','TPU','Vert','#1d9e75',1.75,190,230,0,60,500.00,310.00,34.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL),
(7,'ASA Gris anthracite','Prusament','ASA','Gris anthracite','#888780',1.75,190,230,0,60,1000.00,850.00,32.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL),
(8,'PLA Orange','eSUN','PLA','Orange','#ef9f27',1.75,190,230,0,60,1000.00,930.00,22.90,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,NULL,NULL,20,NULL,NULL);
/*!40000 ALTER TABLE `filaments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_files`
--

DROP TABLE IF EXISTS `library_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL COMMENT 'Nom affiché',
  `original_name` varchar(200) NOT NULL COMMENT 'Nom original du fichier uploadé',
  `file_path` varchar(500) NOT NULL COMMENT 'Chemin relatif sur disque',
  `file_size` bigint(20) NOT NULL COMMENT 'Taille en octets',
  `file_type` enum('stl','3mf','obj','gcode','other') DEFAULT 'stl',
  `theme_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` varchar(500) DEFAULT NULL COMMENT 'Tags séparés par virgule',
  `source_url` varchar(500) DEFAULT NULL COMMENT 'Lien Thingiverse/Printables/etc.',
  `print_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Paramètres suggérés' CHECK (json_valid(`print_settings`)),
  `download_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `object_id` int(11) DEFAULT NULL COMMENT 'Objet auquel appartient ce fichier (NULL = fichier standalone)',
  `part_name` varchar(100) DEFAULT NULL COMMENT 'Nom de la partie ex: Tête, Corps, Bras gauche',
  `recommended_materials` varchar(500) DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL COMMENT 'ex: v1.0, v2.1',
  `changelog` text DEFAULT NULL COMMENT 'Description des changements',
  `parent_file_id` int(11) DEFAULT NULL COMMENT 'Fichier version précédente',
  `is_latest` tinyint(1) DEFAULT 1 COMMENT '1 = version courante',
  PRIMARY KEY (`id`),
  KEY `theme_id` (`theme_id`),
  CONSTRAINT `library_files_ibfk_1` FOREIGN KEY (`theme_id`) REFERENCES `library_themes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_files`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_files` WRITE;
/*!40000 ALTER TABLE `library_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_files` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_object_filaments`
--

DROP TABLE IF EXISTS `library_object_filaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_object_filaments` (
  `object_id` int(11) NOT NULL,
  `filament_id` int(11) NOT NULL,
  `notes` varchar(200) DEFAULT NULL,
  `material` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`object_id`,`filament_id`),
  KEY `filament_id` (`filament_id`),
  CONSTRAINT `library_object_filaments_ibfk_1` FOREIGN KEY (`object_id`) REFERENCES `library_objects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_object_filaments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_object_filaments` WRITE;
/*!40000 ALTER TABLE `library_object_filaments` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_object_filaments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_object_tags`
--

DROP TABLE IF EXISTS `library_object_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_object_tags` (
  `object_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`object_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `library_object_tags_ibfk_1` FOREIGN KEY (`object_id`) REFERENCES `library_objects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `library_object_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `library_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_object_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_object_tags` WRITE;
/*!40000 ALTER TABLE `library_object_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_object_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_objects`
--

DROP TABLE IF EXISTS `library_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_objects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `theme_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` varchar(500) DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `preview_file_id` int(11) DEFAULT NULL COMMENT 'Fichier STL utilisé comme aperçu',
  `photo_path` varchar(500) DEFAULT NULL COMMENT 'Photo de l objet sur disque',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `theme_id` (`theme_id`),
  KEY `fk_objects_preview` (`preview_file_id`),
  CONSTRAINT `fk_objects_preview` FOREIGN KEY (`preview_file_id`) REFERENCES `library_files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `library_objects_ibfk_1` FOREIGN KEY (`theme_id`) REFERENCES `library_themes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_objects`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_objects` WRITE;
/*!40000 ALTER TABLE `library_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_objects` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_tags`
--

DROP TABLE IF EXISTS `library_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_tags` WRITE;
/*!40000 ALTER TABLE `library_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `library_themes`
--

DROP TABLE IF EXISTS `library_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `parent_id` int(11) DEFAULT NULL COMMENT 'NULL = thème racine, sinon sous-thème',
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `library_themes_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `library_themes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_themes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `library_themes` WRITE;
/*!40000 ALTER TABLE `library_themes` DISABLE KEYS */;
INSERT INTO `library_themes` VALUES
(1,'Mécanique',NULL,1,'2026-04-22 18:25:01'),
(2,'Électronique',NULL,2,'2026-04-22 18:25:01'),
(3,'Maison',NULL,3,'2026-04-22 18:25:01'),
(4,'Déco & Art',NULL,4,'2026-04-22 18:25:01'),
(5,'Outillage',NULL,5,'2026-04-22 18:25:01'),
(6,'Robotique',NULL,6,'2026-04-22 18:25:01'),
(7,'Pièces de rechange',NULL,7,'2026-04-22 18:25:01'),
(8,'Prototypes',NULL,8,'2026-04-22 18:25:01');
/*!40000 ALTER TABLE `library_themes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `maintenance`
--

DROP TABLE IF EXISTS `maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `printer_id` int(11) DEFAULT NULL,
  `type` enum('nettoyage','calibration','remplacement_buse','remplacement_plateau','graissage','autre') DEFAULT 'autre',
  `description` text DEFAULT NULL,
  `performed_at` date NOT NULL,
  `next_due` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `printer_id` (`printer_id`),
  CONSTRAINT `maintenance_ibfk_1` FOREIGN KEY (`printer_id`) REFERENCES `printers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `maintenance` WRITE;
/*!40000 ALTER TABLE `maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenance` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `nfc_write_history`
--

DROP TABLE IF EXISTS `nfc_write_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `nfc_write_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filament_id` int(11) NOT NULL,
  `uid` varchar(32) DEFAULT NULL,
  `format` enum('printflow','elegoo') DEFAULT 'elegoo',
  `material` varchar(20) DEFAULT NULL,
  `subtype` varchar(20) DEFAULT NULL,
  `color_hex` varchar(7) DEFAULT NULL,
  `written_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `filament_id` (`filament_id`),
  CONSTRAINT `nfc_write_history_ibfk_1` FOREIGN KEY (`filament_id`) REFERENCES `filaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nfc_write_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `nfc_write_history` WRITE;
/*!40000 ALTER TABLE `nfc_write_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `nfc_write_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `print_filaments`
--

DROP TABLE IF EXISTS `print_filaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `print_filaments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `print_id` int(11) NOT NULL,
  `filament_id` int(11) NOT NULL,
  `sort_order` int(11) DEFAULT 0 COMMENT 'Ordre d impression (1er, 2ème...)',
  `quantity_estimated` decimal(8,2) DEFAULT NULL COMMENT 'Grammes prévus',
  `quantity_actual` decimal(8,2) DEFAULT NULL COMMENT 'Grammes réellement utilisés',
  `notes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `filament_id` (`filament_id`),
  KEY `idx_print_filaments_print` (`print_id`),
  CONSTRAINT `print_filaments_ibfk_1` FOREIGN KEY (`print_id`) REFERENCES `prints` (`id`) ON DELETE CASCADE,
  CONSTRAINT `print_filaments_ibfk_2` FOREIGN KEY (`filament_id`) REFERENCES `filaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_filaments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `print_filaments` WRITE;
/*!40000 ALTER TABLE `print_filaments` DISABLE KEYS */;
/*!40000 ALTER TABLE `print_filaments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `printers`
--

DROP TABLE IF EXISTS `printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `printers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `model` varchar(100) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `interface_type` enum('octoprint','moonraker','bambu','duet','repetier','other') DEFAULT 'other',
  `interface_url` varchar(255) DEFAULT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `volume_x` int(11) DEFAULT 0,
  `volume_y` int(11) DEFAULT 0,
  `volume_z` int(11) DEFAULT 0,
  `nozzle_size` decimal(3,2) DEFAULT 0.40,
  `nozzle_count` int(11) DEFAULT 1,
  `temp_nozzle_max` int(11) DEFAULT 260,
  `temp_bed_max` int(11) DEFAULT 110,
  `location` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('idle','printing','paused','error','offline','maintenance') DEFAULT 'idle',
  `total_prints` int(11) DEFAULT 0,
  `total_success` int(11) DEFAULT 0,
  `total_hours` decimal(10,2) DEFAULT 0.00,
  `total_grams` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `power_consumption` int(11) DEFAULT NULL COMMENT 'Consommation électrique en Watts',
  `has_ams` tinyint(1) DEFAULT 0 COMMENT 'Système multi-filaments AMS/MMU',
  `tapo_ip` varchar(45) DEFAULT NULL COMMENT 'IP de la prise Tapo P100',
  `tapo_mac` varchar(20) DEFAULT NULL COMMENT 'Adresse MAC de la prise Tapo',
  `tapo_state` tinyint(1) DEFAULT 0 COMMENT 'Dernier état connu 0=off 1=on',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `printers` WRITE;
/*!40000 ALTER TABLE `printers` DISABLE KEYS */;
INSERT INTO `printers` VALUES
(1,'Ender 3','Creality Ender 3','192.168.1.101','octoprint','http://192.168.1.101',NULL,220,220,250,0.40,1,260,110,'Atelier',NULL,'idle',18,16,142.00,1240.00,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,0,NULL,NULL,0),
(2,'Prusa MK4','Prusa MK4','192.168.1.102','moonraker','http://192.168.1.102',NULL,250,210,220,0.40,1,300,100,'Atelier',NULL,'printing',22,21,198.00,1870.00,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,0,NULL,NULL,0),
(3,'Bambu X1C','Bambu Lab X1C','192.168.1.103','bambu','http://192.168.1.103',NULL,256,256,256,0.40,1,320,120,'Bureau',NULL,'idle',31,30,210.00,2430.00,'2026-04-22 18:25:00','2026-04-22 18:25:00',NULL,0,NULL,NULL,0);
/*!40000 ALTER TABLE `printers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `prints`
--

DROP TABLE IF EXISTS `prints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL COMMENT 'Pièce du projet à laquelle cette impression appartient',
  `project_item_name` varchar(150) DEFAULT NULL COMMENT 'Nom libre de la pièce (sans pièce formelle)',
  `printer_id` int(11) DEFAULT NULL,
  `filament_id` int(11) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `status` enum('queued','planned','printing','paused','done','failed','cancelled') DEFAULT 'queued',
  `progress` int(11) DEFAULT 0,
  `estimated_duration` int(11) DEFAULT NULL COMMENT 'minutes',
  `actual_duration` int(11) DEFAULT NULL COMMENT 'minutes',
  `filament_used` decimal(8,2) DEFAULT NULL COMMENT 'grams',
  `layer_height` decimal(4,3) DEFAULT NULL,
  `infill_percent` int(11) DEFAULT NULL,
  `print_temp` int(11) DEFAULT NULL,
  `bed_temp` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `real_cost` decimal(8,4) DEFAULT NULL COMMENT 'Coût réel calculé (matière + électricité)',
  `real_filament_cost` decimal(8,4) DEFAULT NULL COMMENT 'Coût matière réel',
  `real_electricity_cost` decimal(8,4) DEFAULT NULL COMMENT 'Coût électricité réel',
  `started_at` timestamp NULL DEFAULT NULL,
  `finished_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `library_file_id` int(11) DEFAULT NULL,
  `library_object_id` int(11) DEFAULT NULL COMMENT 'Objet bibliothèque lié à cette impression',
  `photo_path` varchar(500) DEFAULT NULL COMMENT 'Photo du résultat d impression',
  `library_file_id_v2` int(11) DEFAULT NULL COMMENT 'Fichier STL/3MF utilisé (depuis la bibliothèque)',
  `rating` tinyint(4) DEFAULT NULL COMMENT 'Note de 1 à 5 étoiles',
  `planned_at` datetime DEFAULT NULL COMMENT 'Date/heure planifiée',
  PRIMARY KEY (`id`),
  KEY `printer_id` (`printer_id`),
  KEY `filament_id` (`filament_id`),
  KEY `project_id` (`project_id`),
  KEY `item_id` (`item_id`),
  KEY `fk_prints_library` (`library_file_id`),
  KEY `idx_prints_date` (`created_at`),
  KEY `fk_prints_lib_object` (`library_object_id`),
  CONSTRAINT `fk_prints_lib_object` FOREIGN KEY (`library_object_id`) REFERENCES `library_objects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_prints_library` FOREIGN KEY (`library_file_id`) REFERENCES `library_files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `prints_ibfk_1` FOREIGN KEY (`printer_id`) REFERENCES `printers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `prints_ibfk_2` FOREIGN KEY (`filament_id`) REFERENCES `filaments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `prints_ibfk_3` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `prints_ibfk_4` FOREIGN KEY (`item_id`) REFERENCES `project_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prints`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `prints` WRITE;
/*!40000 ALTER TABLE `prints` DISABLE KEYS */;
/*!40000 ALTER TABLE `prints` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `project_counters`
--

DROP TABLE IF EXISTS `project_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_counters` (
  `ym` char(4) NOT NULL COMMENT 'ex: 2604',
  `last_counter` int(11) DEFAULT 0,
  PRIMARY KEY (`ym`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_counters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `project_counters` WRITE;
/*!40000 ALTER TABLE `project_counters` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_counters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `project_history`
--

DROP TABLE IF EXISTS `project_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `action` varchar(80) NOT NULL COMMENT 'ex: status_changed, item_added…',
  `label` varchar(200) NOT NULL COMMENT 'Texte lisible affiché',
  `detail_before` text DEFAULT NULL,
  `detail_after` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `project_history_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `project_history` WRITE;
/*!40000 ALTER TABLE `project_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `project_items`
--

DROP TABLE IF EXISTS `project_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL COMMENT 'Nom de la pièce ex: Couvercle rouge',
  `description` text DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `project_items_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `project_items` WRITE;
/*!40000 ALTER TABLE `project_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL COMMENT 'ex: P-2604-001',
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('draft','in_progress','done','cancelled') DEFAULT 'draft',
  `status_forced` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `quote_items`
--

DROP TABLE IF EXISTS `quote_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `designation` varchar(255) NOT NULL COMMENT 'Description de la pièce',
  `qty` int(11) DEFAULT 1 COMMENT 'Quantité',
  `print_time_h` decimal(6,2) DEFAULT 0.00 COMMENT 'Durée impression en heures',
  `filament_g` decimal(8,2) DEFAULT 0.00 COMMENT 'Filament consommé en grammes',
  `filament_id` int(11) DEFAULT NULL,
  `printer_id` int(11) DEFAULT NULL,
  `filament_cost` decimal(8,2) DEFAULT 0.00 COMMENT 'Coût matière calculé',
  `electricity_cost` decimal(8,2) DEFAULT 0.00 COMMENT 'Coût électricité calculé',
  `unit_price` decimal(8,2) DEFAULT 0.00 COMMENT 'Prix unitaire HT (avec marge)',
  `sort_order` int(11) DEFAULT 0,
  `print_id` int(11) DEFAULT NULL COMMENT 'Impression réalisée liée',
  PRIMARY KEY (`id`),
  KEY `quote_id` (`quote_id`),
  KEY `filament_id` (`filament_id`),
  KEY `printer_id` (`printer_id`),
  KEY `print_id` (`print_id`),
  CONSTRAINT `quote_items_ibfk_1` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quote_items_ibfk_2` FOREIGN KEY (`filament_id`) REFERENCES `filaments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quote_items_ibfk_3` FOREIGN KEY (`printer_id`) REFERENCES `printers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quote_items_ibfk_4` FOREIGN KEY (`print_id`) REFERENCES `prints` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `quote_items` WRITE;
/*!40000 ALTER TABLE `quote_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) NOT NULL,
  `client_email` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('draft','sent','accepted','refused') DEFAULT 'draft',
  `margin_pct` decimal(5,2) DEFAULT 20.00 COMMENT 'Marge globale en %',
  `total_ht` decimal(8,2) DEFAULT 0.00 COMMENT 'Total calculé depuis les lignes',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `key_name` varchar(50) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
('app_name','PrintFlow-3D','2026-04-22 18:25:01'),
('auth_enabled','false','2026-04-22 18:25:01'),
('auth_password','','2026-04-22 18:25:01'),
('backup_destination','local','2026-04-22 18:25:00'),
('backup_enabled','true','2026-04-22 19:38:43'),
('backup_keep','7','2026-04-22 18:25:00'),
('backup_last_run','','2026-04-22 18:25:00'),
('backup_last_status','','2026-04-22 18:25:00'),
('backup_library_enabled','false','2026-04-22 19:38:43'),
('backup_nas_folder','/printflow','2026-04-22 18:25:00'),
('backup_nas_ip','','2026-04-22 18:25:00'),
('backup_nas_password','','2026-04-22 18:25:00'),
('backup_nas_share','','2026-04-22 18:25:00'),
('backup_nas_user','','2026-04-22 18:25:00'),
('backup_path','/opt/printflow/backups','2026-04-22 18:25:00'),
('backup_report_email','true','2026-04-22 18:25:00'),
('backup_schedule','0 2 * * *','2026-04-22 19:38:43'),
('color_mode','light','2026-04-22 19:38:31'),
('dark_from','20','2026-04-22 18:25:01'),
('dark_to','7','2026-04-22 18:25:01'),
('dashboard_widgets','alert_stock,alert_maintenance,alert_consumables,alert_bobines,metrics,printers_stock,prints_recent,consumption,activity','2026-04-22 18:25:02'),
('electricity_price_kwh','0.20','2026-04-22 18:25:01'),
('gallery_enabled','true','2026-04-22 18:25:02'),
('library_path','/opt/printflow/library','2026-04-22 18:25:00'),
('maintenance_alert_days','30','2026-04-22 18:25:01'),
('maintenance_alert_enabled','true','2026-04-22 18:25:01'),
('prints_photo_path','/opt/printflow/prints','2026-04-22 18:25:01'),
('projects_enabled','true','2026-04-22 18:25:01'),
('push_enabled','false','2026-04-22 18:25:01'),
('quote_company_info','','2026-04-22 18:25:02'),
('quote_company_name','','2026-04-22 18:25:02'),
('quote_electricity_rate','0.20','2026-04-22 18:25:02'),
('quote_margin_default','20','2026-04-22 18:25:02'),
('quotes_enabled','false','2026-04-22 19:38:27'),
('report_day','1','2026-04-22 18:25:01'),
('report_email','','2026-04-22 18:25:01'),
('report_enabled','false','2026-04-22 18:25:01'),
('report_hour','8','2026-04-22 18:25:01'),
('show_locations','false','2026-04-22 19:38:26'),
('show_prices','false','2026-04-22 19:38:25'),
('smtp_from','','2026-04-22 18:25:01'),
('smtp_host','','2026-04-22 18:25:01'),
('smtp_password','','2026-04-22 18:25:01'),
('smtp_port','587','2026-04-22 18:25:01'),
('smtp_secure','false','2026-04-22 18:25:01'),
('smtp_user','','2026-04-22 18:25:01'),
('spoolman_enabled','false','2026-04-22 18:25:00'),
('spoolman_url','http://localhost:7912','2026-04-22 18:25:00'),
('stock_alert_enabled','true','2026-04-22 18:25:01'),
('stock_alert_threshold','20','2026-04-22 18:25:01'),
('tapo_email','','2026-04-22 18:25:02'),
('tapo_enabled','false','2026-04-22 18:25:02'),
('tapo_password','','2026-04-22 18:25:02'),
('theme','blue','2026-04-22 18:25:00'),
('vapid_private','7e5MelnrE22vXe_PaN2yHi6ssjhHNu_O7-dBr8BxjmY','2026-04-22 18:26:25'),
('vapid_public','BDnbd3NpJ9nxkbrke-4IwjKPJo6vXs9GLZmZUXyIFZ-b6AcdNd4dSNXTcY9hU3IcmRJljJsS_VwnqG9GyhtVyPs','2026-04-22 18:26:25');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-04-22 21:39:35
